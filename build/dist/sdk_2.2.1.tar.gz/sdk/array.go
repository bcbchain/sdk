package sdk

// Array 将多个对象转换成一个切片进行表示
func Array(items ...interface{}) []interface{} {
	return items
}
